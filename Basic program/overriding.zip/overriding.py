class Colour():
    def fun(self):
        print("colour is ")
class Blue(Colour):
    pass
obj=Blue()
obj.fun()
        
