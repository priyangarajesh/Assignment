a=int(input("Enter the value"))
b=int(input("Enter the value"))
if a>b:
    print("yes")
else:
    print("no")

