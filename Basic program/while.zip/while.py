count=1
while count<=10:
    print ("welcome to python class")
    count+=1
   
