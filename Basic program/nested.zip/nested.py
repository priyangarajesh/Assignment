count=1
newcount=1
while count<=5:
    print("hello")
    newcount=1
    while newcount<=5:  
        print("you are welcome")
        newcount+=1
    count+=1
 
