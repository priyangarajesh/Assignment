a="WELCOME"
for i in range(len(a)):
    print(i)

