class ABC : 
    def method_abc (self): 
        print(" colourful world ") 
  
class_ref = ABC() 
class_ref.method_abc()
