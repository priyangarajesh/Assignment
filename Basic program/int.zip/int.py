X=int(1)
Y=int(2.8)
print(X)
print(Y)
