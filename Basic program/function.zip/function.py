a=int(input())
b=int(input())
def myfunc(a,b):
    c=a+b
    d=a*b
    return c,d
f=myfunc(a,b)
print(f)
