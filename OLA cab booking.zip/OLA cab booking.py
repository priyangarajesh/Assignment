print("Sign-in form")
n=str(input(print("name:")))
c=int(input(print("contact:")))
print("Thank you for downloding the UBER app…")
print("Successfully completed")
print("*****************")
print("searching for a cab or auto")
print("******************")
s=str(input("pick up:"))
d1=str(input("drop:"))
d=float(input("distance:"))
t=int(input("time:"))
print("available auto/cab....")
print("1.OLA AUTO(per km=1.00INR)")
print(("2.OLA MINI(per km=2.50INR"))
print("3.OLA PRIME(per km=4.50INR)")
start1=1.00
start2=2.50
start3=4.50
speed=d/t
if d<=10:
   amount1=(d*0.7)+start1
   amount2=(d*0.7)+start2
   amount3 = (d * 0.7) + start3
   print("distance:",d)
   print("your amount for OLA AUTO:",amount1,"INR")
   print("your amount for OLA MINI:", amount2,"INR")
   print("your amount for OLA PRIME:", amount3,"INR")
   print("speed:",speed,"inches/minute")
elif d>10:
 amount1=((d-10)*30)+8.20
 amount2=((d-10)*30)+10.00
 amount3= ((d - 10) * 30) + 12.00
 print("distance:",d)
 print("your amount for OLA AUTO:",amount1,"INR")
 print("your amount for OLA MINI:", amount2,"INR")
 print("your amount for OLA PRIME:", amount3,"INR")
 print("speed",speed,"inches/minute")
else:
 exit(0)
enter=str(input("if the amount is stastify enter(yes/no)"))
if(enter=="yes"):
 print("welcome to OLA")
 print("your OTP:7755")
 print("car number:TN8743")
 print("Contact number:9942752977")
 print("Thanks for booking OLA cab")
else:
     exit(0)
