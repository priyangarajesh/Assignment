print("welcome to KPN Travels ")
restart = ('y')

while restart !=('N','NO','n','no'):
     print("1.check status")
     print("2.Ticket Reservation")
     option = int(input("Enter your option :"))

     if option == 1:
         print("your status is t2")
         exit(0)

     elif option == 2:
         passanger = int(input("Enter no of ticket you want :"))
         seatno_1 = []
         name_1 = []
         age_1=[]
         for p in range(passanger):
             seatno = str(input("seatno :"))
             seatno_1.append(seatno)
             name = str(input(" name :"))
             name_1.append(name)
             age = int(input("age :"))
             age_1.append(age) 
         restart= str(input ("To proceed(YES/NO)"))
         if restart in ("YES"):
            restart = ("YES")
         else:
            x = ("NO")
            print("Total Ticket :",passanger)
            for p in range(1,passanger+1):
               print("Ticket :",p)
               print("seatno :",seatno_1[x])
               print("name :",name_1[x])
               print("age :",age_1[x])
               x +=1
    
             
         
 
