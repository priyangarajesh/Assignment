import csv
with open('company.csv','r')as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
